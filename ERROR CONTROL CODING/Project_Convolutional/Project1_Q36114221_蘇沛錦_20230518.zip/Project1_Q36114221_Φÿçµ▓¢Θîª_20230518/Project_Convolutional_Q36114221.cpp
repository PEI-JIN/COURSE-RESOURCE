//  Project: ECC - Decoding of Convolutional Codes	(電通所 Q36114221 蘇沛錦)
//  Written by SU PEI-JIN on May 4, 2023.
//  Consider the (2, 1, 6) convolutional code with generator matrix
//      G(D) = (1 + D^2 + D^3 + D^5 + D^6   1 + D + D^2 + D^3 + D^6)
//  Latest release (May 18, 2023)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

/* Define Variables */
int n = 2;  // Length of codeword
int m = 6;  // Number of delay elements for convolutional encoder

/* Define state register */
int sReg[7]; // Define an array sReg as state register

void Parser(char* filename, int* N, int* L, double* SNR_dB, long* SEED, int* choice)
{
    FILE *fp;
    char buffer[50];
    int buffer_flag;

    if((fp=fopen(filename,"r"))==NULL){
        printf("!!! Input File Does Not Exist !!!\n");
        system("pause");
        exit(0);
    }
    else{
        // printf("Input %s\n",filename);

        fscanf(fp, "%d", N);
        // printf(" %d",*N);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        // if(buffer_flag != 0){
        //     printf("%s\n", buffer);
        // }
        // else{
        //     putchar('\n');
        // }

        fscanf(fp, "%d", L);
        // printf(" %d",*L);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        // if(buffer_flag != 0){
        //     printf("%s\n", buffer);
        // }
        // else{
        //     putchar('\n');
        // }

        fscanf(fp, "%lf", SNR_dB);
        // printf(" %.1lf",*SNR_dB);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        // if(buffer_flag != 0){
        //     printf("%s\n", buffer);
        // }
        // else{
        //     putchar('\n');
        // }

        fscanf(fp, "%ld", SEED);
        // printf(" %ld",*SEED);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        // if(buffer_flag != 0){
        //     printf("%s\n", buffer);
        // }
        // else{
        //     putchar('\n');
        // }

        fscanf(fp, "%d", choice);
        // printf(" %d",*choice);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        // if(buffer_flag != 0){
        //     printf("%s\n", buffer);
        // }
        // else{
        //     putchar('\n');
        // }

        fclose(fp);
    }
}

/* Information Bits Generator */
int* Info_Bits_Gen(int L)
{
    int i;       // for loop counter
    int* u = (int*)calloc(L,sizeof(int));   // Information bits

    if(L <= 6){
        u[0] = 1;
    }
    else{
        for(i=0;(i+6)<L;i++){
            if(i==0){
                u[i] = 1;
            }
            u[i+6] = (u[i+1]+u[i])%2;
        }
    }

    return u;
}

/* Encoder */
int* Encoder(int u)
{
    int* c = (int*)calloc(n,sizeof(int));   // Information bits

    c[0] = (u + sReg[1] + sReg[2] + sReg[4] + sReg[5])%2;
    c[1] = (u + sReg[0] + sReg[1] + sReg[2] + sReg[5])%2;

    sReg[5] = sReg[4];
	sReg[4] = sReg[3];
	sReg[3] = sReg[2];
	sReg[2] = sReg[1];
	sReg[1] = sReg[0];
    sReg[0] = u;

    return c;
}

/* Modulator */
int Modulator(int c)
{
    int x;   // Modulated Symbols

    if (c == 0)
    {
        x = 1;
    }
    else if (c == 1)
    {
        x = -1;
    }

    return x;
}

/* AWGN channel */
double ran1(long *idum)
{
    int j;
    long k;
    static long iy=0;
    static long iv[NTAB];
    double temp;
    if (*idum <= 0 || !iy){
        if (-(*idum) < 1) *idum=1;
        else *idum = -(*idum);
        for (j=NTAB+7;j>=0;j--){
            k=(*idum)/IQ;
            *idum=IA*(*idum-k*IQ)-IR*k;
            if (*idum < 0) *idum += IM;
            if (j < NTAB) iv[j] = *idum;
        }
        iy=iv[0];
    }
    k=(*idum)/IQ;
    *idum=IA*(*idum-k*IQ)-IR*k;
    if (*idum < 0) *idum += IM;
    j=iy/NDIV;
    iy=iv[j];
    iv[j] = *idum;
    if ((temp=AM*iy) > RNMX) return RNMX;
    else return temp;
}

void normal(double* n1, double* n2, double sigma, long* idum)
{
    double x1, x2, s;

    do{
        x1 = ran1(idum);
        x2 = ran1(idum);
        x1 = 2*x1 - 1;
        x2 = 2*x2 - 1;
        s = x1*x1 + x2*x2;
    } while (s >= 1.0);
    *n1 = sigma*x1*sqrt(-2*log(s)/s);
    *n2 = sigma*x2*sqrt(-2*log(s)/s);
}

/* Convert integers to bits */
void int2bit(int value, int* s0, int* s1, int* s2, int* s3, int* s4, int* s5, int* s6)
{
    *s0 = value%2;
    *s1 = (value/2)%2;
    *s2 = (value/4)%2;
    *s3 = (value/8)%2;
    *s4 = (value/16)%2;
    *s5 = (value/32)%2;
    *s6 = (value/64)%2;
}

/* Convert bits to integers */
int bit2int(int s0, int s1, int s2, int s3, int s4, int s5, int s6, int num_bit)
{
    int value = 0;
    switch (num_bit)
    {
        case 6:
            value = 32*s5 + 16*s4 + 8*s3 + 4*s2 + 2*s1 + s0;
            break;
        case 7:
            value = 64*s6 + 32*s5 + 16*s4 + 8*s3 + 4*s2 + 2*s1 + s0;
            break;
        default:
            break;
    }
    return value;
}

/* branch codeword computation (BCC) */
int* BCC(int s0, int s1, int s2, int s3, int s4, int s5, int s6)
{
    int* x = (int*)calloc(2, sizeof(int));   // branch codeword
    x[0] = (s0 + s2 + s3 + s5 + s6)%2;
    x[1] = (s0 + s1 + s2 + s3 + s6)%2;
    return x;
}

/* Hard Limiter */
void HL(int* y_est0, int* y_est1, double y0, double y1)
{
    if (y0 >= 0)
    {
        *y_est0 = 0;
    }
    else
    {
        *y_est0 = 1;
    }

    if (y1 >= 0)
    {
        *y_est1 = 0;
    }
    else
    {
        *y_est1 = 1;
    }
    
}

/* branch metric computation (BMC) */
void BMC(double* bMet, int** stateSur, double y0, double y1, int TW_Idx, int choice)
{
    int i;          // for loop counter
    int bMet_Idx;   // bMet (branch metric memory) address
    int* x;         // branch codeword
    int y_est0, y_est1;

    for (i = 0; i < 128; i++) bMet[i] = -1;      // 將記憶體區塊內的值初始化    
    
    if (TW_Idx == 0)
    {
        int2bit(0, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
        x = BCC(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6]);  // branch codeword computation (BCC)
        bMet_Idx = bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 7);
        stateSur[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 6)][TW_Idx] = 65;        
        switch (choice)
        {
            case 0:     // 0=>Hard-decision; 1=>Soft-decision
            {
                HL(&y_est0, &y_est1, y0, y1);
                bMet[bMet_Idx] = (x[0] + y_est0)%2 + (x[1] + y_est1)%2;
                break;
            }
            
            case 1:     // 0=>Hard-decision; 1=>Soft-decision
            {
                y_est0 = Modulator(x[0]);
                y_est1 = Modulator(x[1]);
                bMet[bMet_Idx] = (y_est0 - y0)*(y_est0 - y0) + (y_est1 - y1)*(y_est1 - y1);
                break;
            }

            default:
                break;
        }
            
        int2bit(1, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
        x = BCC(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6]);  // branch codeword computation (BCC)
        bMet_Idx = bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 7);
        stateSur[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 6)][TW_Idx] = 65;
        switch (choice)
        {
            case 0:     // 0=>Hard-decision; 1=>Soft-decision
            {
                HL(&y_est0, &y_est1, y0, y1);
                bMet[bMet_Idx] = (x[0] + y_est0)%2 + (x[1] + y_est1)%2;
                break;
            }
            
            case 1:     // 0=>Hard-decision; 1=>Soft-decision
            {
                y_est0 = Modulator(x[0]);
                y_est1 = Modulator(x[1]);
                bMet[bMet_Idx] = (y_est0 - y0)*(y_est0 - y0) + (y_est1 - y1)*(y_est1 - y1);
                break;
            }

            default:
                break;
        }
    }
    else if (TW_Idx < 0)
    {
        for (i = 0; i < 64; i++)
        {
            if (stateSur[i][-(TW_Idx)-1] != -1)
            {
                int2bit(2*i, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
                x = BCC(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6]);  // branch codeword computation (BCC)
                bMet_Idx = bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 7);
                stateSur[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 6)][-(TW_Idx)] = 65;
                switch (choice)
                {
                    case 0:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        HL(&y_est0, &y_est1, y0, y1);
                        bMet[bMet_Idx] = (x[0] + y_est0)%2 + (x[1] + y_est1)%2;
                        break;
                    }
                    
                    case 1:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        y_est0 = Modulator(x[0]);
                        y_est1 = Modulator(x[1]);
                        bMet[bMet_Idx] = (y_est0 - y0)*(y_est0 - y0) + (y_est1 - y1)*(y_est1 - y1);
                        break;
                    }

                    default:
                        break;
                }
            }
        }
    }
    else
    {
        for (i = 0; i < 64; i++)
        {
            if (stateSur[i][TW_Idx-1] != -1)
            {
                int2bit(2*i, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
                x = BCC(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6]);  // branch codeword computation (BCC)
                bMet_Idx = bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 7);
                stateSur[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 6)][TW_Idx] = 65;
                switch (choice)
                {
                    case 0:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        HL(&y_est0, &y_est1, y0, y1);
                        bMet[bMet_Idx] = (x[0] + y_est0)%2 + (x[1] + y_est1)%2;
                        break;
                    }
                    
                    case 1:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        y_est0 = Modulator(x[0]);
                        y_est1 = Modulator(x[1]);
                        bMet[bMet_Idx] = (y_est0 - y0)*(y_est0 - y0) + (y_est1 - y1)*(y_est1 - y1);
                        break;
                    }

                    default:
                        break;
                }
                    
                int2bit(2*i+1, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
                x = BCC(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6]);  // branch codeword computation (BCC)
                bMet_Idx = bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 7);
                stateSur[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], sReg[6], 6)][TW_Idx] = 65;
                switch (choice)
                {
                    case 0:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        HL(&y_est0, &y_est1, y0, y1);
                        bMet[bMet_Idx] = (x[0] + y_est0)%2 + (x[1] + y_est1)%2;
                        break;
                    }
                    
                    case 1:     // 0=>Hard-decision; 1=>Soft-decision
                    {
                        y_est0 = Modulator(x[0]);
                        y_est1 = Modulator(x[1]);
                        bMet[bMet_Idx] = (y_est0 - y0)*(y_est0 - y0) + (y_est1 - y1)*(y_est1 - y1);
                        break;
                    }

                    default:
                        break;
                }
            }
        }
    }
    
    free(x);    // 釋放由指標變數所指向的記憶空間
}

/* add-compare and select  (ACS) */
void ACS(double* bMet, int** stateSur, double** stateMet, int TW_Idx)
{
    int i;              // for loop counter
    double bMet0, bMet1;   // branch metric
    int stateMet_Idx;   // stateMet (state metric memory) address (previous)
    double m0, m1;

    for (i = 0; i < 64; i++)
    {
        if (stateSur[i][TW_Idx] != -1)
        {
            int2bit(i, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);

            bMet0 = bMet[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 0, 7)];  // 上面 branch 的 metric
            bMet1 = bMet[bit2int(sReg[0], sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 1, 7)];  // 下面 branch 的 metric

            if (bMet0 != -1 && bMet1 == -1)         // 只有上面 branch 的 metric 有值
            {
                stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 0, 0, 6);
                stateMet[i][1] = stateMet[stateMet_Idx][0] + bMet0;
            }
            else if (bMet0 == -1 && bMet1 != -1)    // 只有下面 branch 的 metric 有值
            {
                stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 1, 0, 6);
                stateMet[i][1] = stateMet[stateMet_Idx][0] + bMet1;
            }
            else    // 兩個 branch 的 metric 皆有值 -> 選擇 metric 最小的 branch
            {
                stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 0, 0, 6);
                m0 = stateMet[stateMet_Idx][0] + bMet0;

                stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 1, 0, 6);
                m1 = stateMet[stateMet_Idx][0] + bMet1;

                if (m0 > m1)
                {
                    stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 1, 0, 6);
                    stateMet[i][1] = stateMet[stateMet_Idx][0] + bMet1;
                }
                else    // 遇到同樣大小的 metric 時，總是選最上面的 branch
                {
                    stateMet_Idx = bit2int(sReg[1], sReg[2], sReg[3], sReg[4], sReg[5], 0, 0, 6);
                    stateMet[i][1] = stateMet[stateMet_Idx][0] + bMet0;
                }
            }
            stateSur[i][TW_Idx] = stateMet_Idx;     // Survivor updating
        }
    }

    for ( i = 0; i < 64; i++)
    {
        stateMet[i][0] = stateMet[i][1];    // 移動暫存器的內容
        stateMet[i][1] = -1;    // 將記憶體區塊內的值初始化
    }
    
}

/* traceback decoding (TBD) */
int* TBD(int** stateSur, double** stateMet, int L, int TBD_ctrl)
{
    int i;   // for loop counter
    int* u_est = (int*)calloc(L, sizeof(int));   // branch codeword
    double minMet = stateMet[0][0]; // minimum state metric
    int TB_Idx = 0; // traceback index

    switch (TBD_ctrl)
    {
        case 0:
            /* Best-state */
            for (i = 1; i < 64; i++)
            {
                if (stateMet[i][0] < minMet && stateSur[i][L-1] != -1)
                {
                    minMet = stateMet[i][0];
                    TB_Idx = i;
                }             
            }
            break;    
        default:    // 最終 trellis diagram 必定收斂到 00 這個 state
            break;
    }

    for (i = 0; i < L; i++)     // Perform trace-back for output
    {
        int2bit(TB_Idx, &sReg[0], &sReg[1], &sReg[2], &sReg[3], &sReg[4], &sReg[5], &sReg[6]);
        u_est[(L-1)-i] = sReg[0];
        TB_Idx = stateSur[TB_Idx][(L-1)-i];         
    }    

    return u_est;
}

/* Viterbi decoder */
int* vitdec(double* y, int L, int N, int choice)
{
    int i, j, k;    // for loop counter

    double* bMet;          // branch metric memory
    double** stateMet;     // state metric memory
    int** stateSur;     // state survivor memory
    int* u_est;         // Estimated information bits
    int* uReg;          // Data registers can hold estimated information bits

    int TW_Idx = 0;     // "TW_Idx" is the abbreviation for "truncation window index".
    int u_Idx = 0;      // Address register for "Estimated information bits"

    /* 規劃所需記憶體空間 */
    bMet = (double*)malloc(sizeof(double)*128);
    stateMet = (double**)malloc(sizeof(double*)*64);
    stateSur = (int**)malloc(sizeof(int*)*64);
    u_est = (int*)malloc(sizeof(int)*N);

    /* 初始化記憶體區塊 */
    for (i = 0; i < N; i++) u_est[i] = -1;      // 將記憶體區塊內的值初始化
    for (i = 0; i < 64; i++)
    {
        stateMet[i] = (double*)malloc(sizeof(double)*2);
        for (j = 0; j < 2; j++) stateMet[i][j] = -1;      // 將記憶體區塊內的值初始化
        stateSur[i] = (int*)malloc(sizeof(int)*L);
        for (j = 0; j < L; j++) stateSur[i][j] = -1;      // 將記憶體區塊內的值初始化
    }
    stateMet[0][0] = 0.0;     // 設定初始 state (00) 的 metric 數值為 0.0

    /* 印出結果核對 */
    // switch (choice)     // 0=>Hard-decision; 1=>Soft-decision
    // {
    //     case 0:
    //         printf("%d=>Hard-decision\n", choice);
    //         break;
    //     
    //     case 1:
    //         printf("%d=>Soft-decision\n", choice);
    //         break;
    //     
    //     default:
    //         break;
    // }

    /* 執行 Viterbi 演算法 */
    for (i = 0; i < (N + m); i++)
    {
        if (i < N)
        {
            /* branch metric computation (BMC) */
            BMC(bMet, stateSur, y[2*i], y[2*i+1], TW_Idx, choice);
        }
        else
        {
            /* branch metric computation (BMC) */
            BMC(bMet, stateSur, y[2*i], y[2*i+1], -TW_Idx, choice);
        }

        /* add-compare and select  (ACS) */
        ACS(bMet, stateSur, stateMet, TW_Idx);

        /* Sliding Window */
        if (TW_Idx == L-1)
        {
            if (i == (N + m - 1))   // 跑完整個 trellis diagram 的情況
            {
                /* traceback decoding (TBD) */
                uReg = TBD(stateSur, stateMet, L, 1);
                for (j = 0; u_Idx < N; j++)
                {
                    u_est[u_Idx] = uReg[j];
                    u_Idx = u_Idx + 1;
                }                
            }
            else    // 尚未跑完整個 trellis diagram
            {
                /* traceback decoding (TBD) */
                uReg = TBD(stateSur, stateMet, L, 0);
                u_est[u_Idx] = uReg[0];
                u_Idx = u_Idx + 1;
            }
            
            for (j = 0; j < 64; j++)
            {
                for (k = 0; k < (L-1); k++)
                {
                    stateSur[j][k] = stateSur[j][k+1];
                }
                stateSur[j][L-1] = -1;                
            }

            // Deallocate memory block
            free(uReg);         // 釋放由指標變數所指向的記憶空間
        }
        else
        {
            TW_Idx = TW_Idx + 1;
        }
    }

    // Deallocate memory block
    free(bMet);         // 釋放由指標變數所指向的記憶空間
    for (i = 0; i < 64; i++)
    {
        free(stateMet[i]);
        free(stateSur[i]);
    }
    free(stateMet);     // 釋放由指標變數所指向的記憶空間
    free(stateSur);     // 釋放由指標變數所指向的記憶空間

    return u_est;
}

/* Printf */
void Printf(double* y, int* u_est, int N, int choice)
{
    int i;  // for loop counter
    int y_est0, y_est1;

    switch (choice)      // 0=>Hard-decision; 1=>Soft-decision
    {
        case 0:
        {
            char Output_filename[20] = "Output_Hard.txt";

            FILE *fp;
            fp = fopen(Output_filename,"w");
            // printf("Output %s\n", Output_filename);
            for(i = 0;i < (N + m); i++)
            {
                HL(&y_est0, &y_est1, y[n*i], y[n*i + 1]);
                // printf(" %d %d", y_est0, y_est1);
                fprintf(fp,"%d %d ", y_est0, y_est1);
            }
            // printf(" %%hard-decision output: %d*(N+m) elements\n",n);
            fprintf(fp,"%%hard-decision output: %d*(N+m) elements\n",n);

            for(i = 0;i < N; i++)
            {
                // printf(" %d",u_est[i]);
                fprintf(fp,"%d ",u_est[i]);
            }
            // printf(" %%decoded information bits");
            fprintf(fp,"%%decoded information bits");
            fclose(fp);

            break;
        }

        case 1:
        {
            char Output_filename[20] = "Output_Soft.txt";

            FILE *fp;
            fp = fopen(Output_filename,"w");
            // printf("Output %s\n", Output_filename);
            for(i = 0;i < n*(N + m); i++)
            {
                // printf(" %lf", y[i]);
                fprintf(fp,"%lf ", y[i]);
            }
            // printf(" %%y: %d*(N+m) elements\n",n);
            fprintf(fp,"%%y: %d*(N+m) elements\n",n);

            for(i = 0;i < N; i++)
            {
                // printf(" %d",u_est[i]);
                fprintf(fp,"%d ",u_est[i]);
            }
            // printf(" %%decoded information bits");
            fprintf(fp,"%%decoded information bits");
            fclose(fp);

            break;
        }
        
        default:
            break;
    }
}

int main(void)
{
    int i, j;   // for loop counter
    char Input_filename[30] = "Sim.txt";

    int N;  // Number of decoded bits
    int L;  // Truncation Window Length
    double SNR_dB; // Bit signal-to-noise ratio (dB)
    long SEED;   // Seed: a negative integer
    int choice; // 0=>Hard-decision; 1=>Soft-decision
    double SNR; // Bit signal-to-noise ratio 
    double sigma;   // standard deviation of the noise

    int* u; // Point to the memory of Information Bits
    int* c; // Point to the temporary register of Codeword
    int* x; // Point to the temporary register of Modulated Symbols
    double* z; // Point to the temporary register of Noise
    double* y; // Point to the memory of Received Symbols
    int* u_est;         // Estimated information bits    

    /* Parser */
    // printf("-> Parser\n");
    Parser(Input_filename, &N, &L, &SNR_dB, &SEED, &choice);

    /* Information Bits Generator */
    // putchar('\n');
    // printf("-> Information Bits Generator\n");
    u = Info_Bits_Gen(N);
    // printf("Information bits (u): \n");
    // for(i=0;i<N;i++){
    //     printf(" %d", u[i]);
    // }
    // putchar('\n');

    // Initializing state register
    for(i=0;i<m;i++){
		sReg[i] = 0;
	}

    // Initializing registers of Codeword, Modulated Symbols, and Noise, resp.
    c = (int*)calloc(n,sizeof(int));   // Codeword
    x = (int*)calloc(n,sizeof(int));   // Modulated Symbols
    z = (double*)calloc(n,sizeof(double));   // Noise
    // Initializing memory of Received Symbols
    y = (double*)calloc(n*(N+m),sizeof(double));   // Received Symbols

    // Prerequisite for AWGN channel
    long *idum;
    idum = (long *)malloc(sizeof(long));
    *idum = SEED;   // SEED must be a negative integer

    SNR = pow(10,SNR_dB/10.0);
    sigma = sqrt(1/SNR);
    
    for(i=0;i<(N+m);i++){
        /* Encoder */
        // printf("\n-> Encoder\n");
        // printf(" Input: u(%d) = %d\n", i, u[i]);
        if(i<N){
            c = Encoder(u[i]);
        }
        else{
            c = Encoder(0);
        }
        // printf(" Output: c(%d) = (%d, %d)\n", i, c[0], c[1]);

        /* Modulator */
        // printf("-> Modulator\n");
        x[0] = Modulator(c[0]);
        x[1] = Modulator(c[1]);
        // printf(" Output: x(%d) = (%d, %d)\n", i, x[0], x[1]);

        /* AWGN channel */
        // printf("-> AWGN channel\n");
        normal(&z[0], &z[1], sigma, idum);
        // printf(" Noise: n(%d) = (%lf, %lf)\n", i, z[0], z[1]);
        y[i*n] = x[0] + z[0];
        y[i*n+1] = x[1] + z[1];
        // printf(" Recived Symbols: y(%d) = (%lf, %lf)\n", i, y[i*n], y[i*n+1]);     
    }

    /* Viterbi decoder */
    // putchar('\n');
    // printf("-> Viterbi decoder\n");
    u_est = vitdec(y, L, N, choice);    // Convolutionally decode binary data by using Viterbi algorithm
    // printf("Decoded information bits (u): \n");
    // for(i=0;i<N;i++){
    //     printf(" %d", u_est[i]);
    // }
    // putchar('\n');

    // Deallocate the memory previously allocated by a call to calloc
    free(c);
    free(x);
    free(z);

    /* Printf */
    // printf("\n-> Printf\n");
    Printf(y, u_est, N, choice);
    // putchar('\n');

    // Deallocate the memory previously allocated by a call to calloc
    free(u);
    free(idum);
    free(y);
    free(u_est);

    system("pause");
    return 0;
}