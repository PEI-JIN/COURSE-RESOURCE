// Project: Error Control Coding - Hamming Codes (ML decoder, Ver. 1)
// Q36114221 電通所 蘇沛錦 (2023/03/27 完成)
// 此程式碼是參照老師講義 PTT 上的 Block Diagram 進行編寫，
// 將每個功能區塊盡可能獨立成副函式進行呼叫。
// 解碼器則是使用 Maximum-Likelihood (ML) decoder。

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Data Structure */
struct Hamming_Codes_Info
{
    /* data */
    int n;      // Block length
    int r;      // No. Parity bits
    int** H;    // Parity-check matrix
    int m;      // No. Error patterns
    int** Z;    // Error patterns
};

/* Parser */
struct Hamming_Codes_Info Parser(char* filename)
{
    struct Hamming_Codes_Info Sim_Input;
    FILE *fp;
    char buffer[50];
    int buffer_flag;
    int i, j;   // for loop counter

    if((fp=fopen(filename,"r"))==NULL){
        printf("!!! Input File Does Not Exist !!!\n");
        system("pause");
        exit(0);
    }
    else{
        printf("Input %s\n",filename);

        fscanf(fp, "%d", &Sim_Input.n);
        printf(" %d",Sim_Input.n);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        if(buffer_flag != 0){
            printf("%s\n", buffer);
        }
        else{
            putchar('\n');
        }

        fscanf(fp, "%d", &Sim_Input.r);
        printf(" %d",Sim_Input.r);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        if(buffer_flag != 0){
            printf("%s\n", buffer);
        }
        else{
            putchar('\n');
        }

        Sim_Input.H = (int**)calloc(Sim_Input.r, sizeof(int*));
        for(i=0;i<Sim_Input.r;i++){
            Sim_Input.H[i] = (int*)calloc(Sim_Input.n, sizeof(int));
        }

        for(i=0;i<Sim_Input.r;i++){
            for(j=0;j<Sim_Input.n;j++){
                if(i==1 && j==0){
                    buffer_flag = fscanf(fp, "%[^\n]", buffer);
                    if(buffer_flag != 0){
                        printf("%s\n", buffer);
                    }
                    else{
                        putchar('\n');
                    }
                    fscanf(fp, "%d", &Sim_Input.H[i][j]);
                    printf(" %d",Sim_Input.H[i][j]);
                }
                else{
                    fscanf(fp, "%d", &Sim_Input.H[i][j]);
                    printf(" %d",Sim_Input.H[i][j]);
                }
            }
            if(i >= 1){
                putchar('\n');
            }
        }

        fscanf(fp, "%d", &Sim_Input.m);
        printf(" %d",Sim_Input.m);
        buffer_flag = fscanf(fp, "%[^\n]", buffer);
        if(buffer_flag != 0){
            printf("%s\n", buffer);
        }
        else{
            putchar('\n');
        }

        Sim_Input.Z = (int**)calloc(Sim_Input.m, sizeof(int*));
        for(i=0;i<Sim_Input.m;i++){
            Sim_Input.Z[i] = (int*)calloc(Sim_Input.n, sizeof(int));
        }

        for(i=0;i<Sim_Input.m;i++){
            for(j=0;j<Sim_Input.n;j++){
                if(i!=0 && j==0){
                    buffer_flag = fscanf(fp, "%[^\n]", buffer);
                    if(buffer_flag != 0){
                        printf("%s\n", buffer);
                    }
                    else{
                        putchar('\n');
                    }
                    fscanf(fp, "%d", &Sim_Input.Z[i][j]);
                    printf(" %d",Sim_Input.Z[i][j]);
                }
                else{
                    fscanf(fp, "%d", &Sim_Input.Z[i][j]);
                    printf(" %d",Sim_Input.Z[i][j]);
                }
            }
        }

        if(fgets(buffer, sizeof(buffer), fp) != NULL){
            puts(buffer);
        }
        else{
            putchar('\n');
        }

        fclose(fp);
    }

    return Sim_Input;
}

/* H to G */
int** H_to_G(int** H, int n, int r)
{
    int i, j;       // for loop counter
    int k = n-r;    // No. Information bits
    int** G;        // Generator matrix
    G = (int**)calloc(k, sizeof(int*));
    for(i=0;i<k;i++){
        G[i] = (int*)calloc(n, sizeof(int));
    }
    for(i=0;i<k;i++){
        for(j=0;j<n;j++){
            if(j>=k){
                G[i][j] = H[j-k][i];
            }
            else if(j<k && i==j){
                G[i][j] = 1;
            }
        }
    }

    return G;
}

/* Information Bits Generator */
int* Info_Bits_Gen(int m, int k)
{
    int i;       // for loop counter
    int l = m*k;    // No. Information bits
    int* u = (int*)calloc(l,sizeof(int));   // Information bits

    for(i=0;(i+6)<l;i++){
        if(i==0){
            u[i] = 1;
        }
        u[i+6] = (u[i+1]+u[i])%2;
    }

    return u;
}

/* Encoder */
int* Encoder(int** G, int* u, int n, int k)
{
    int i, j;       // for loop counter
    int* x = (int*)calloc(n,sizeof(int));   // Codeword
    int sum;

    for(i=0;i<n;i++){
        sum = 0;
        for(j=0;j<k;j++){
            sum = (sum + u[j]*G[j][i])%2;
		}
        x[i] = sum;
    }

    return x;
}

/* y = x + z */
int* Channel(int** Z, int* x, int n, int m, int index)
{
    int i, j;       // for loop counter
    int* y = (int*)calloc(n,sizeof(int));  // Garbled codeword

    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            y[j] = (x[j] + Z[index][j])%2;
        }
    }

    return y;
}

/* Maximum-Likelihood (ML) Decoder */
int* ML_Decoder(int** G, int* y, int n, int r, int index)
{
    int i, j, p;       // for loop counter
    int k = n-r;    // No. Information bits
    int* x_est = (int*)calloc(n,sizeof(int));   // Estimated Codeword
    int* u_est = (int*)calloc(k,sizeof(int));   // Estimated information bits

    int num_code = pow(2,k);    // No. Codewords

    int* bin_counter = (int*)calloc(k,sizeof(int));         // Binary counter
    int* err_counter = (int*)calloc(num_code,sizeof(int));  // Error counter
    int temp_mem, counter;

    int** C;    // Codewords set
    C = (int**)calloc(num_code,sizeof(int*));
    for(i=0;i<num_code;i++){
        C[i] = (int*)calloc(n, sizeof(int));
    }

    int temp_min, col_Idx;

    for(i=0;i<num_code;i++){
        /* Binary Counter */
        counter = i;
        for(j=k-1;j>=0;j--){
            temp_mem = pow(2,j);
            if(counter>=temp_mem){
                counter = counter - temp_mem;
                bin_counter[j] = 1;
            }
            else{
                bin_counter[j] = 0;
            }
        }

        /* Codewords Generator */
        for(j=0;j<k;j++){
            for(p=0;p<n;p++){
                C[i][p] = (C[i][p] + G[j][p]*bin_counter[j])%2;
            }
        }

        /* Error Counter */
        for(j=0;j<n;j++){
            err_counter[i] = err_counter[i] + (C[i][j] + y[j])%2;
        }
    }

    /* Minimum Distance Decoding */
    col_Idx = 0;
    temp_min = err_counter[col_Idx];
    for(i=1;i<num_code;i++){
        if(temp_min > err_counter[i]){
            temp_min = err_counter[i];
            col_Idx = i;
        }
    }

    for(i=0;i<n;i++){
        x_est[i] = C[col_Idx][i];
        if(i<k){
            u_est[i] = x_est[i];
        }
        printf(" %d",x_est[i]);
    }
    printf(" %%Est. x%d\n",index);

    // Deallocate the memory previously allocated by a call to calloc
    for(i=0;i<num_code;i++){
        free(C[i]);
    }
    free(bin_counter);
    free(err_counter);
    free(x_est);
    free(C);

    return u_est;
}

/* Printf */
void Printf(char* filename, int* u, int k, int index)
{
    int i;  // for loop counter
	FILE *fp;

    if(index == 0){
        fp = fopen(filename,"w");
    }
    else{
        fp = fopen(filename,"a");
    }

	printf("Output %s\n", filename);
	for(i=0;i<k;i++){
        printf(" %d",u[i]);
        fprintf(fp,"%d ",u[i]);
	}
    printf(" %%Est. u%d\n",index);
    fprintf(fp,"%%Est. u%d\n",index);
	fclose(fp);
}

int main(void)
{
    int i, j;   // for loop counter
    char Input_filename[30] = "Sim.txt";
    char Output_filename[20] = "u.txt";
    struct Hamming_Codes_Info Sim_Input;

    /* Parser */
    printf("-> Parser\n");
    Sim_Input = Parser(Input_filename);

    putchar('\n');
    printf("Parity-check matrix (H):\n");
    for(i=0;i<Sim_Input.r;i++){
        for(j=0;j<Sim_Input.n;j++){
            printf(" %d",Sim_Input.H[i][j]);
        }
        putchar('\n');
    }

    putchar('\n');
    printf("Error patterns (Z):\n");
    for(i=0;i<Sim_Input.m;i++){
        for(j=0;j<Sim_Input.n;j++){
            printf(" %d",Sim_Input.Z[i][j]);
        }
        putchar('\n');
    }

    /* H to G */
    putchar('\n');
    printf("-> H to G\n");
    int** G;    // Generator matrix
    int k = Sim_Input.n - Sim_Input.r;  // No. Information bits
    G = H_to_G(Sim_Input.H, Sim_Input.n, Sim_Input.r);

    printf("Generator matrix (G):\n");
    for(i=0;i<k;i++){
        for(j=0;j<Sim_Input.n;j++){
            printf(" %d",G[i][j]);
        }
        putchar('\n');
    }

    /* Information Bits Generator */
    putchar('\n');
    printf("-> Information Bits Generator\n");
    int* u;
    int l = Sim_Input.m*k;    // No. Information bits
    u = Info_Bits_Gen(Sim_Input.m, k);
    printf("Information bits (u): \n");
    for(i=0;i<l;i++){
        printf(" %d", u[i]);
    }
    putchar('\n');

    int* u_block;   // Information bits
    u_block = (int*)calloc(k,sizeof(int));
    int* x;         // Codeword
    int* y;         // Garbled codeword
    int* u_est;         // Estimate codeword

    for(i=0;i<Sim_Input.m;i++){
        /* Encoder */
        putchar('\n');
        printf("-> Encoder\n");
        for(j=0;j<k;j++){
            u_block[j] = u[i*k + j];
            printf(" %d", u_block[j]);
        }
        printf(" %%Information bits u%d\n",i);

        x = Encoder(G, u_block, Sim_Input.n, k);
        for(j=0;j<Sim_Input.n;j++){
            printf(" %d", x[j]);
        }
        printf(" %%Codeword x%d\n",i);

        /* y = x + z */
        y = Channel(Sim_Input.Z, x, Sim_Input.n, Sim_Input.m, i);
        printf("-> y = x + z\n");
        for(j=0;j<Sim_Input.n;j++){
            printf(" %d", Sim_Input.Z[i][j]);
        }
        printf(" %%Error pattern z%d\n",i);

        for(j=0;j<Sim_Input.n;j++){
            printf(" %d", y[j]);
        }
        printf(" %%Garbled codeword y%d\n",i);

        // Deallocate the memory previously allocated by a call to calloc
        free(x);

        /* Maximum-Likelihood (ML) Decoder */
        printf("-> Maximum-Likelihood (ML) Decoder\n");
        u_est = ML_Decoder(G, y, Sim_Input.n, Sim_Input.r, i);

        // Deallocate the memory previously allocated by a call to calloc
        free(y);

        /* Printf */
        printf("-> Printf\n");
        Printf(Output_filename, u_est, k, i);

        // Deallocate the memory previously allocated by a call to calloc
        free(u_est);
    }
    putchar('\n');

    // Deallocate the memory previously allocated by a call to calloc
    for(i=0;i<Sim_Input.r;i++){
        free(Sim_Input.H[i]);
    }
    free(Sim_Input.H);

    for(i=0;i<k;i++){
        free(G[i]);
    }
    free(G);

    for(i=0;i<Sim_Input.m;i++){
        free(Sim_Input.Z[i]);
    }
    free(Sim_Input.Z);

    free(u);
    free(u_block);

    system("pause");

    return 0;
}